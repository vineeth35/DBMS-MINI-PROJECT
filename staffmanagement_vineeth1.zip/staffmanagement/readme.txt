Commands:

pip install flask

pip install flask_mysqldb